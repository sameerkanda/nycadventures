<?php
class parseConfig{
	const APPID = 'CapTJvjAtrMgMZuLqkPfzw71qO2vgzyeaUcJPU2c';
	const MASTERKEY = 'onzW1F0PHZ7YK9hE1H75b8ME3dN6Ku54l4Lbnd9E';
	const RESTKEY = 'iUdjmsM3oOoEIOH2ymv9Xr1EHfn7trngZfdr4SzY';
	const PARSEURL = 'https://api.parse.com/1/';
}
